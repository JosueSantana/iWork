# :information_source: Iwork

O Iwork é um projeto que tem como objetivo desenvolver uma aplicação que facilite a interação
entre empresas e clientes no âmbito de prestações de serviços domésticos, onde o
cliente seleciona sua opção dentre diversos tipos de serviços prestados, empresas e
funcionários, de forma em que todos os envolvidos possam modernizar a forma com a
qual operam intuitivamente, prezando a todo momento pela praticidade na experiência
de todos os usuários.

## Alunos integrantes da equipe

* Igor Daniel Hamzi Weston
* Grazielle Sorrentino Santos Souza
* Luísa Ferreira Marques
* Nicole Marie Agnelo Marques
* Gabriel Dias Nogueira
* Josué Santana Melo

## Professores responsáveis

* Pedro Felipe Alves de Oliveira


## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
